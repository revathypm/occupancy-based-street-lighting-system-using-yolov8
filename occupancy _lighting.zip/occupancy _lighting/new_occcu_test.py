from ultralytics import YOLO
import cv2
import math
import time

# Running real-time from webcam
cap = cv2.VideoCapture(0)

# Load COCO model for person detection
coco_model = YOLO('yolov8n.pt')

# Reading the classes
coco_classnames = coco_model.names

# Classes to include
included_classes = ['person', 'motorcycle', 'bicycle', 'truck', 'bus', 'car']

# Set up video writer
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi', fourcc, 20.0, (640, 480))

# Counter for each included class
class_counters = {class_name: 0 for class_name in included_classes}

# Threshold for continuous detection
continuous_threshold = 5  # Adjust as needed

# Last detection time
last_detection_time = time.time()

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.resize(frame, (640, 480))

    # Perform object detection using COCO model
    coco_result = coco_model(frame, stream=True)

    # Process results for specified classes
    detection_flag = False
    for info in coco_result:
        boxes = info.boxes
        for box in boxes:
            confidence = box.conf[0]
            confidence = math.ceil(confidence * 100)
            Class = int(box.cls[0])
            class_name = coco_classnames[Class]
            if confidence > 20 and class_name in included_classes:
                detection_flag = True
                # Draw bounding box
                x1, y1, x2, y2 = box.xyxy[0]
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                # Increment counter for this class
                class_counters[class_name] += 1
                if class_counters[class_name] >= continuous_threshold:
                    print("1")
            else:
                print("0")

    # Check if any included class is detected
    if detection_flag:
        print("detect")
        last_detection_time = time.time()
    else:
        print("non")
        # Check if 1 second has passed without detection
        if time.time() - last_detection_time > 1:
            print("hii")

    out.write(frame)

    cv2.imshow('frame', frame)
    if cv2.waitKey(1) & 0xFF == ord('d'):
        break

    # Sleep for a short duration to limit the frame processing rate
    time.sleep(0.1)

cap.release()
out.release()
cv2.destroyAllWindows()

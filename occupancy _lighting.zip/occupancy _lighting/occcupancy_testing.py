import serial
import time

ser = serial.Serial('COM3', 115200, timeout=1)

def send_to_arduino(value):
    ser.write(str.encode(value))
    time.sleep(0.1)

send_to_arduino('A')
print('A')

time.sleep(1)

from ultralytics import YOLO
import cv2
import math
import serial
import time

# Running real-time from webcam
cap = cv2.VideoCapture(0)

# Load COCO model for person detection
coco_model = YOLO('yolov8n.pt')

# Reading the classes
coco_classnames = coco_model.names

# Classes to include
included_classes = ['person', 'motorcycle', 'bicycles', 'truck', 'bus', 'car']

# Set up video writer
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi', fourcc, 20.0, (640, 480))

# Set up serial communication with Arduino
ser = serial.Serial('COM3', 115200, timeout=1)

def send_to_arduino(value):
    ser.write(value.encode())
    time.sleep(1)  # Add a delay to ensure the Arduino has enough time to process the command

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.resize(frame, (640, 480))

    # Perform object detection using COCO model
    coco_result = coco_model(frame, stream=True)

    # Process results for specified classes
    for info in coco_result:
        boxes = info.boxes
        for box in boxes:
            confidence = box.conf[0]
            confidence = math.ceil(confidence * 100)
            Class = int(box.cls[0])
            class_name = coco_classnames[Class]
            if confidence > 20 and class_name in included_classes:
                # Your code for specified classes goes here
                # For now, just drawing the bounding box
                x1, y1, x2, y2 = box.xyxy[0]
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                
                # Send '1' to Arduino when included classes detected
                send_to_arduino('A')
            else:
                # Send '0' to Arduino when excluded classes detected
                send_to_arduino('B')

    out.write(frame)

    cv2.imshow('frame', frame)
    cv2.waitKey(1)

    #Read and print data from Arduino Serial Monitor
    if ser.in_waiting > 0:
        serial_data = ser.readline().decode('utf-8').rstrip()
        print(serial_data)

    if cv2.waitKey(20) & 0xFF == ord('d'):
        break

cap.release()
out.release()
cv2.destroyAllWindows()
ser.close()
